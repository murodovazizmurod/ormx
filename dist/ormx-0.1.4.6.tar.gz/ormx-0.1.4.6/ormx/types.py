DESC = 'DESC'
ASC = 'ASC'

ORDER_BY_PARAMS = [
    ASC,
    DESC
]

__all__ = [
    'DESC',
    'ASC',
    'ORDER_BY_PARAMS'
]

